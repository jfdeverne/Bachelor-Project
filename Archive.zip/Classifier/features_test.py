import nltk
import random
import pickle
import re
from nltk.corpus import PlaintextCorpusReader
from nltk.tokenize import RegexpTokenizer
from nltk.corpus.util import LazyCorpusLoader
from nltk.corpus.reader import *
import os
import sys
import codecs
import operator

db = LazyCorpusLoader(
    "sustainable_db", CategorizedPlaintextCorpusReader,
    r'(?!\.).*\.txt', cat_pattern=r'(neg|pos)/.*',
    encoding='utf-8')

documents = [(list(db.words(fileid)), category) #retrieve the collection of documents
			for category in db.categories()
			for fileid in db.fileids(category)]

input_to_classify = [] # a list of strings to classify
docnames = [] # a list of filenames corresponding to the above list
docs = dict()

random.shuffle(documents) #this is to prevent training and testing on the same data

all_words = [] #all words in collection

for w in db.words():
	all_words.append(w.lower())

all_words = nltk.FreqDist(all_words)

word_features = list(all_words.keys()[:3000])

def get_keywords(): #imports the keywords from the given input text document
    global keywords
    filename = sys.argv[1]
    f = open(filename, 'r')
    file_content = f.read().strip()
    keywords = file_content.split('\n')

def remove_biased(featurelist): #if keywords were used for classification, this will reduce bias
	for element in featurelist:
		if element in keywords:
			featurelist.remove(element)

def find_features(document):
	words = set(document)
	return dict([(word, True) for word in words])

def load_input_to_classify():
	global input_to_classify
	global docs
	for filename in os.listdir(os.getcwd() + "/classify_this"):
		try:
			f = open("classify_this/" + filename, 'r')
			file_content = f.read().strip()
			input_to_classify.append(file_content)
			docnames.append(filename)
		except:
			print(filename + " " + "is not a valid filename.")
		docs = dict(zip(docnames, input_to_classify))

if (len(sys.argv) == 2):
	get_keywords()
	remove_biased(word_features)
	print(word_features)

featuresets = [(find_features(rev), category) for (rev, category) in documents]
test_set = featuresets[700:]

classifier_file = open("classifier.pickle", "rb")
classifier = pickle.load(classifier_file)
classifier_file.close()

load_input_to_classify()

for name in docs:
	content = docs[name]
	classify_tokens = content.split()
	name = re.sub(".txt", "", name)
	try:
		result = classifier.classify(find_features(classify_tokens))
		if (result == "pos"):
			print(name)
	except:
		print(name + ": " + "Encoding error, try setting global encoding to UTF-8.")


