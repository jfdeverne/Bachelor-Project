import nltk
import random
import pickle
import re
import sys
from nltk.corpus import movie_reviews

from nltk.classify.scikitlearn import SklearnClassifier
from sklearn.naive_bayes import MultinomialNB, GaussianNB, BernoulliNB
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.svm import SVC, LinearSVC, NuSVC


db = movie_reviews

documents = [(list(db.words(fileid)), category) #retrieve the collection of documents
			for category in db.categories()
			for fileid in db.fileids(category)]

random.shuffle(documents) #this is to prevent training and testing on the same data

all_words = []

for w in db.words():
	all_words.append(w.lower())

all_words = nltk.FreqDist(all_words)

word_features = list(all_words.keys()[:3000])

def find_features(document):
	words = set(document)
	features = {}
	for w in word_features:
		features[w] = (w in words)
	return features

featuresets = [(find_features(rev), category) for (rev, category) in documents]
training_set = featuresets[:1900]

def classify(mode):
	help_string = " -k: Keyword matching \n -n: Naive Bayes. \n -m: Multinomial NB \n -b: Bernoulli NB \n -l: Logistic Regression \n -s: SGD \n -t: SVC \n -u: NuSVC \n -v: Linear SVC"
	if mode == '-k':
		#use keywords only, no classification (copy the steps from corpus builder)
		print ("Your input will be searched for the given keywords.")
		sys.exit(4)
	elif mode == "-n":
		print ("Your input will be classified using the Naive Bayes classifier.")
		classifier = nltk.NaiveBayesClassifier.train(training_set)
	elif mode == "-m":
		print ("Your input will be classified using the Multinomial NB classifier.")
		classifier = SklearnClassifier(MultinomialNB()).train(training_set)
	elif mode == "-b":
		print ("Your input will be classified using the Bernoulli NB classifier.")
		classifier = SklearnClassifier(BernoulliNB()).train(training_set)
	elif mode == "-l":
		print ("Your input will be classified using the Logistic Regression classifier.")
		classifier = SklearnClassifier(LogisticRegression()).train(training_set)
	elif mode == "-s":
		print ("Your input will be classified using the SGD classifier.")
		classifier = SklearnClassifier(SGDClassifier()).train(training_set)
	elif mode == "-t":
		print ("Your input will be classified using the SVC classifier.")
		classifier = SklearnClassifier(SVC()).train(training_set)
	elif mode == "-u":
		print ("Your input will be classified using the NuSVC classifier.")
		classifier = SklearnClassifier(NuSVC()).train(training_set)
	elif mode == "-v":
		print ("Your input will be classified using the Linear SVC classifier.")
		classifier = SklearnClassifier(LinearSVC()).train(training_set)
	elif mode == "-help":
		print (help_string)
		sys.exit(3)
	else:
		print ("Unknown argument provided. Use argument -help for more information.")
		sys.exit(2)

	save_classifier = open("classifier.pickle", "wb")
	pickle.dump(classifier, save_classifier)
	save_classifier.close()
	print("The classifier has been trained. Use features_test.py to classify your input.")

def main():
	if (len(sys.argv) < 2):
		print("Usage: python features_train.py <mode>")
		sys.exit(1)
	mode = sys.argv[1]
	classify(mode)

main()
