import nltk
import random
import pickle
import re
from nltk.corpus import movie_reviews
from nltk.tokenize import RegexpTokenizer
from nltk.corpus.util import LazyCorpusLoader
from nltk.corpus.reader import *

db = movie_reviews

documents = [(list(db.words(fileid)), category) #retrieve the collection of documents
			for category in db.categories()
			for fileid in db.fileids(category)]

random.shuffle(documents) #this is to prevent training and testing on the same data

all_words = [] #all words in the corpus

for w in db.words():
	all_words.append(w.lower())

all_words = nltk.FreqDist(all_words)

word_features = list(all_words.keys()[:3000])

def find_features(document):
	words = set(document)
	return dict([(word, True) for word in words])

featuresets = [(find_features(rev), category) for (rev, category) in documents]
test_set = featuresets[:1900]

classifier_file = open("classifier.pickle", "rb")
classifier = pickle.load(classifier_file)
classifier_file.close()

print("Accuracy %:", (nltk.classify.accuracy(classifier, test_set))*100)
